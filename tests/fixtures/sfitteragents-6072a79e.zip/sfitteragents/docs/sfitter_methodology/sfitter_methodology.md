# SFitter Methodology

Documentation of the SFitter global SMEFT fitting framework, derived from the Plehn group publication lineage. All content sourced from peer-reviewed publications.

## Contents

| File | Description |
|------|-------------|
| [01_sfitter_framework.md](01_sfitter_framework.md) | SFitter core framework: RFit scheme (flat theory uncertainties), profiling vs marginalization, weighted Markov chain, likelihood construction, the three uncertainty distributions |
| [02_publication_lineage.md](02_publication_lineage.md) | Paper-by-paper summary of the SFitter SMEFT program: operator sets, datasets, methodology evolution from SUSY (2007) through combined Top+Higgs (2023) to ML-accelerated (2024) |
| [03_dataset_and_operators.md](03_dataset_and_operators.md) | Complete listing of measurements and operators used in the current SFitter global fit, with specific tool versions, PDF sets, and scale choices |

## Key References (SFitter group)

| Year | arXiv | Title | Role |
|------|-------|-------|------|
| 2007 | 0709.3985 | Measuring Supersymmetry | **Original SFitter paper** — RFit, weighted Markov chain |
| 2015 | (reference removed) | The Higgs Legacy of the LHC Run I | First SFitter SMEFT analysis (Higgs) |
| 2018 | (reference removed) | The Gauge-Higgs Legacy of the LHC Run II | Higgs + EW + diboson SMEFT, kinematic distributions |
| 2019 | (reference removed) | O new physics, where art thou? | **Foundational top-sector SMEFT** — establishes operator set + dataset |
| 2022 | (reference removed) | To Profile or To Marginalize | Profiling vs Bayesian, flat vs Gaussian theory uncertainties |
| 2023 | (reference removed) | Staying on Top of SMEFT-Likelihood Analyses | **Combined Top + Higgs + EW**, published likelihoods, Schmal thesis |
| 2024 | (reference removed) | Profile Likelihoods on ML-Steroids | ML-accelerated profile likelihood |
| 2024 | (reference removed) | Refinable modeling for unbinned SMEFT | Unbinned ML approach |
| 2024 | (reference removed) | A Global View of the EDM Landscape | CP-violating sector, EDMs |
